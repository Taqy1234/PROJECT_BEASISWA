import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(400, 600, 1);
        viewactor();
    }
    public void viewactor()
    {
        addObject(new pesawat(), 200, 550);
        addObject(new misil1(), 45, 50);
        addObject(new misil2(), 90, 50);
        addObject(new misil3(), 135, 50);
        addObject(new misil4(), 180, 50);
        addObject(new misil5(), 225, 50);
        addObject(new misil6(), 270, 50);
        addObject(new misil7(), 315, 50);
        addObject(new misil8(), 360, 50);
        nilai counter = new nilai ();
        addObject(counter, -0, 800);
        counter.setLocation(70, 580);
    }
}
