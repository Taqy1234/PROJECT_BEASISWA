import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class misil4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class misil4 extends Actor
{
    /**
     * Act - do whatever the misil4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY() + 4); // Gerak turun
        if (getY() >= 599) {
            setLocation(getX(), 20); // Kembali ke atas
        }
        pesawat D = (pesawat)getOneIntersectingObject(pesawat.class);
            if(D!=null)
        {
        Greenfoot.playSound("explode.wav");
        setImage("end.png");
        Greenfoot.stop();
        }
    }
}
