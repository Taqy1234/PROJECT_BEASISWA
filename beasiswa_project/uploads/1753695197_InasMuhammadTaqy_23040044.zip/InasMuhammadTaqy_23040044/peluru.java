import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class peluru here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class peluru extends Actor
{
    private nilai nilai;
    /**
     * Act - do whatever the peluru wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY()-10);
        if(getY() <=20)
        {
            setLocation(getX(),getY());
            Greenfoot.playSound("fire.wav");
            getWorld().removeObject(this);
            return;
        }
        misil1 A = (misil1)getOneIntersectingObject(misil1.class);
        if(A!=null)
        {
        getWorld().removeObject(A);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil2 B = (misil2)getOneIntersectingObject(misil2.class);
        if(B!=null)
        {
        getWorld().removeObject(B);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil3 C = (misil3)getOneIntersectingObject(misil3.class);
        if(C!=null)
        {
        getWorld().removeObject(C);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil4 D = (misil4)getOneIntersectingObject(misil4.class);
        if(D!=null)
        {
        getWorld().removeObject(D);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil5 E = (misil5)getOneIntersectingObject(misil5.class);
        if(E!=null)
        {
        getWorld().removeObject(E);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil6 F = (misil6)getOneIntersectingObject(misil6.class);
        if(F!=null)
        {
        getWorld().removeObject(F);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil7 G = (misil7)getOneIntersectingObject(misil7.class);
        if(G!=null)
        {
        getWorld().removeObject(G);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
        misil8 H = (misil8)getOneIntersectingObject(misil8.class);
        if(H!=null)
        {
        getWorld().removeObject(H);
        Greenfoot.playSound("explode.wav");
        nilai nilai = getnilai();
        nilai.nilai();
        getWorld().addObject(new Explosion(), getX(), getY());
        getWorld().removeObject(this);
        return;
        }
    }
     public nilai getnilai()
    {
        return (nilai)getWorld().getObjects(nilai.class).iterator().next();
    }
}
