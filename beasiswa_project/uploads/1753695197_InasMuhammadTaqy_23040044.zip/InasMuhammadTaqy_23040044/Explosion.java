import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion extends Actor
{
    private int transparency = 255;
    /**
     * Act - do whatever the Explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (transparency > 0) {
            transparency -= 5; // Kurangi transparansi secara perlahan
            getImage().setTransparency(transparency);
            } 
        else {
        getWorld().removeObject(this); // Hapus setelah transparansi 0
            }
    }
}
