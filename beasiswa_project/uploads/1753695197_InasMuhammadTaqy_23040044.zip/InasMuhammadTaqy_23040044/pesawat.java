import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pesawat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pesawat extends Actor
{
    private MyWorld peluru;
    /**
     * Act - do whatever the pesawat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void addedToWorld(World MyWorld)
    {
        peluru = (MyWorld)MyWorld;
    }
    public void act()
    {
        setLocation(getX(), getY() - 4); // Gerak naik
        if (getY() <= 20) {
        setLocation(getX(), 599); // Kembali ke bawah
        }
         if(Greenfoot.isKeyDown("left"))
        {
        setLocation(getX()-4, getY());
        }
        if(Greenfoot.isKeyDown("right"))
        {
        setLocation(getX()+4, getY());
        }
         if(Greenfoot.isKeyDown("x"))
        {
            if (peluru != null) {
            peluru.addObject(new peluru(), getX(), getY());
            }
        }
    }
}
