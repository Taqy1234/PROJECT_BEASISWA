import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Color;
import java.awt.Font;
/**
 * Write a description of class nilai here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nilai extends Actor
{
    private int value = 0;
    private int target = 0;
    private String text;
    private int stringLength;
    int point = 0;
    /**
     * Act - do whatever the nilai wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public nilai()
    {
       tambah();
    }

     public void nilai()
    {
        point++;
        tambah();
        if(point == 8)
        {
            Greenfoot.playSound("Menang.mp3");
            setImage("you win.png");
            setLocation(200, 300);
        }
    }
    
    public void tambah()
    {
        GreenfootImage Nilai = new GreenfootImage("Score : " + point, 32, Color.WHITE, Color.BLACK);
        setImage(Nilai);
    }
}
