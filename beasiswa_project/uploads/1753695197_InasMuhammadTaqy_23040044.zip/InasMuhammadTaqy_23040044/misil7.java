import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class misil7 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class misil7 extends Actor
{
    /**
     * Act - do whatever the misil7 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY() + 2); // Gerak turun
        if (getY() >= 599) {
            setLocation(getX(), 20); // Kembali ke atas
        }
        pesawat G = (pesawat)getOneIntersectingObject(pesawat.class);
            if(G!=null)
        {
        Greenfoot.playSound("explode.wav");
        setImage("end.png");
        Greenfoot.stop();
        }
    }
}
